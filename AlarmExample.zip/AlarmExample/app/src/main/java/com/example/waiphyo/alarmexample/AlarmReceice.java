package com.example.waiphyo.alarmexample;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

public class AlarmReceice extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    @Override

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yourlayout);
        mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.aa);
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();
    }
}
